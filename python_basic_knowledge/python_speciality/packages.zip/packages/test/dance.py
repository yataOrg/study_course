#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author: yata
# @Date:   2019-06-20 18:57:28
# @Last Modified by:   yata
# @Last Modified time: 2019-06-20 18:58:24

class Dance(object):

	def show(self):
		print("this is show method")


	def dance(self):
		print("this is dance method")
