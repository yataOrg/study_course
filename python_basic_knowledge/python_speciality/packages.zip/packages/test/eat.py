#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author: yata
# @Date:   2019-06-20 18:58:38
# @Last Modified by:   yata
# @Last Modified time: 2019-06-20 18:59:25

class Eat(object):

	def show(self):
		print("我是eat类的 show 方法")

	def eat(self):
		print("this is eat method")
