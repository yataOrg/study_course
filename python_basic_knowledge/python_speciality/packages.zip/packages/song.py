#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author: yata
# @Date:   2019-06-20 18:48:21
# @Last Modified by:   yata
# @Last Modified time: 2019-06-20 19:00:46


class Song(object):

	def song(self):
			print("唱歌")


	def show(self):
		print('show')



