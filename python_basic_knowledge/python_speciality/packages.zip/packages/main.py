#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author: yata
# @Date:   2019-06-20 18:49:37
# @Last Modified by:   yata
# @Last Modified time: 2019-06-20 19:04:09

# 模块

'''
import song

obj = song.Song()
obj.song()
obj.show()
'''

from test import dance,eat

danceObj = dance.Dance()
danceObj.show()

eatObj = eat.Eat()
eatObj.eat()